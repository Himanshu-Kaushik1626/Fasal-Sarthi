import { useState } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface FloatingChatbotProps {
  language: string;
}

export const FloatingChatbot = ({ language }: FloatingChatbotProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello Farmer 👨‍🌾! I am Fasal Sarthi, ask me about any crop disease, tips, or farming help.",
      sender: 'bot',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const getWelcomeMessage = (lang: string) => {
    const welcomeMessages: Record<string, string> = {
      en: "Hello Farmer 👨‍🌾! I am Fasal Sarthi, ask me about any crop disease, tips, or farming help.",
      hi: "नमस्कार किसान भाई 👨‍🌾! मैं फसल सारथी हूं, फसल की बीमारी, सुझाव या खेती की मदद के लिए पूछें।",
      bn: "হ্যালো কৃষক ভাই 👨‍🌾! আমি ফসল সারথি, ফসলের রোগ, পরামর্শ বা কৃষি সহায়তার জন্য জিজ্ঞাসা করুন।",
      te: "హలో రైతు అన్న 👨‍🌾! నేను ఫసల్ సారథి, పంట వ్యాధులు, సలహాలు లేదా వ్యవసాయ సహాయం గురించి అడగండి।",
      mr: "नमस्कार शेतकरी भाऊ 👨‍🌾! मी फसल सारथी आहे, पिकांचे रोग, सल्ला किंवा शेतीच्या मदतीसाठी विचारा।",
      ta: "வணக்கம் விவசாயி அண்ணா 👨‍🌾! நான் பசல் சாரதி, பயிர் நோய்கள், ஆலோசனைகள் அல்லது விவசாய உதவிக்காக கேளுங்கள்।"
    };
    return welcomeMessages[lang] || welcomeMessages.en;
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    const botResponse: Message = {
      id: messages.length + 2,
      text: "Thank you for your question! This is a demo chatbot. In the full version, I would provide detailed farming advice and solutions.",
      sender: 'bot',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage, botResponse]);
    setInputMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Button */}
      <Button
        onClick={() => setIsOpen(true)}
        className="floating-chat"
        size="lg"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 z-50 w-80 h-96 flex flex-col shadow-2xl border-border/50 bg-card">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border/50 primary-gradient text-primary-foreground">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5" />
              <span className="font-semibold">Fasal Sarthi</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 text-primary-foreground hover:bg-white/20"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-3 text-sm ${
                      message.sender === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border/50">
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about crops, diseases..."
                className="flex-1"
              />
              <Button onClick={handleSendMessage} size="icon" className="shrink-0">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}
    </>
  );
};