import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { MainLayout } from "./layouts/MainLayout";
import { Home } from "./pages/Home";
import { Crops } from "./pages/Crops";
import { CropDetail } from "./pages/CropDetail";
import { Auth } from "./pages/Auth";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={
            <MainLayout>
              <Home language="en" />
            </MainLayout>
          } />
          <Route path="/crops" element={
            <MainLayout>
              <Crops language="en" />
            </MainLayout>
          } />
          <Route path="/crop/:cropName" element={
            <MainLayout>
              <CropDetail language="en" />
            </MainLayout>
          } />
          <Route path="/profile" element={<Auth language="en" />} />
          <Route path="/login" element={<Auth language="en" />} />
          <Route path="/resources" element={
            <MainLayout>
              <div className="container mx-auto px-4 py-16 text-center">
                <h1 className="text-4xl font-bold mb-4">Resources Coming Soon</h1>
                <p className="text-lg text-muted-foreground">Digital library and farming guides will be available here.</p>
              </div>
            </MainLayout>
          } />
          <Route path="/chat" element={
            <MainLayout>
              <div className="container mx-auto px-4 py-16 text-center">
                <h1 className="text-4xl font-bold mb-4">AI Chatbot</h1>
                <p className="text-lg text-muted-foreground">Use the floating chatbot button in the bottom-right corner!</p>
              </div>
            </MainLayout>
          } />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
