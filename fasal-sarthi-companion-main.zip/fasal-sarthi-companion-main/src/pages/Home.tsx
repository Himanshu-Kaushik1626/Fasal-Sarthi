import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Sprout, BookOpen, MessageCircle, TrendingUp, Shield, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface HomeProps {
  language: string;
}

const popularCrops = [
  { name: "Wheat", icon: "🌾", diseases: 12, tips: 25 },
  { name: "Rice", icon: "🍚", diseases: 18, tips: 32 },
  { name: "Maize", icon: "🌽", diseases: 15, tips: 28 },
  { name: "Cotton", icon: "🌸", diseases: 22, tips: 35 },
  { name: "Sugarcane", icon: "🎋", diseases: 14, tips: 22 },
  { name: "Soybean", icon: "🫘", diseases: 16, tips: 30 }
];

const features = [
  {
    icon: MessageCircle,
    title: "AI Chatbot Assistant",
    description: "Get instant answers about crop diseases, farming techniques, and agricultural best practices from our intelligent farming assistant."
  },
  {
    icon: Sprout,
    title: "Comprehensive Crop Guide",
    description: "Access detailed information about various crops including growing conditions, disease management, and yield optimization strategies."
  },
  {
    icon: BookOpen,
    title: "Digital Library",
    description: "Browse through our extensive collection of agricultural books, guides, and research papers to enhance your farming knowledge."
  },
  {
    icon: Shield,
    title: "Disease Prevention",
    description: "Learn about common crop diseases, their symptoms, and effective prevention and treatment methods to protect your harvest."
  },
  {
    icon: TrendingUp,
    title: "Yield Optimization",
    description: "Discover proven techniques and modern farming practices to maximize your crop yield and improve farm productivity."
  },
  {
    icon: Users,
    title: "Community Support",
    description: "Connect with fellow farmers, share experiences, and learn from agricultural experts in your native language."
  }
];

export const Home = ({ language }: HomeProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/crop/${searchQuery.toLowerCase().replace(/\s+/g, '-')}`);
    }
  };

  const handleCropClick = (cropName: string) => {
    navigate(`/crop/${cropName.toLowerCase()}`);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-20 lg:py-32">
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Welcome to <span className="text-primary-glow">Fasal Sarthi</span>
              </h1>
              <p className="text-xl sm:text-2xl text-white/90 max-w-3xl mx-auto">
                Your Smart Crop Companion 🌱
              </p>
              <p className="text-lg text-white/80 max-w-2xl mx-auto">
                Empowering farmers with AI-driven insights, comprehensive crop guides, and expert agricultural knowledge in your native language.
              </p>
            </div>

            {/* Hero Search */}
            <form onSubmit={handleSearch} className="max-w-md mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search for any crop..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-24 py-6 text-lg bg-white/95 backdrop-blur-sm border-0 shadow-lg"
                />
                <Button 
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2"
                >
                  Search
                </Button>
              </div>
            </form>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                onClick={() => navigate('/crops')}
                variant="secondary" 
                size="lg"
                className="bg-white/20 text-white border-white/30 hover:bg-white/30"
              >
                <Sprout className="mr-2 h-5 w-5" />
                Browse Crops
              </Button>
              <Button 
                onClick={() => navigate('/chat')}
                variant="secondary" 
                size="lg"
                className="bg-white/20 text-white border-white/30 hover:bg-white/30"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Ask AI Assistant
              </Button>
              <Button 
                onClick={() => navigate('/resources')}
                variant="secondary" 
                size="lg"
                className="bg-white/20 text-white border-white/30 hover:bg-white/30"
              >
                <BookOpen className="mr-2 h-5 w-5" />
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Crops Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Popular Crops
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Quick access to information about the most commonly grown crops
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {popularCrops.map((crop) => (
              <Card 
                key={crop.name}
                className="crop-card cursor-pointer group"
                onClick={() => handleCropClick(crop.name)}
              >
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">{crop.icon}</div>
                  <h3 className="font-semibold text-card-foreground mb-2">{crop.name}</h3>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>{crop.diseases} diseases covered</div>
                    <div>{crop.tips} tips available</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Why Choose Fasal Sarthi?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive agricultural support designed specifically for Indian farmers
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="crop-card">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 primary-gradient">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold text-white">
              Ready to Transform Your Farming?
            </h2>
            <p className="text-xl text-white/90">
              Join thousands of farmers who are already using Fasal Sarthi to improve their crop yields and farming knowledge.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                onClick={() => navigate('/profile')}
                size="lg"
                variant="secondary"
                className="bg-white text-primary hover:bg-white/90"
              >
                Get Started Today
              </Button>
              <Button 
                onClick={() => navigate('/chat')}
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10"
              >
                Try AI Assistant
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};