import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Filter, Grid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface CropsProps {
  language: string;
}

const crops = [
  { 
    name: "Wheat", 
    emoji: "🌾", 
    category: "Cereal", 
    season: "Rabi", 
    diseases: 12, 
    tips: 25,
    description: "Major cereal crop, staple food for billions"
  },
  { 
    name: "Rice", 
    emoji: "🍚", 
    category: "Cereal", 
    season: "Kharif", 
    diseases: 18, 
    tips: 32,
    description: "Primary food crop for more than half world's population"
  },
  { 
    name: "Maize", 
    emoji: "🌽", 
    category: "Cereal", 
    season: "Both", 
    diseases: 15, 
    tips: 28,
    description: "Versatile crop used for food, feed, and industrial purposes"
  },
  { 
    name: "Cotton", 
    emoji: "🌸", 
    category: "Fiber", 
    season: "Kharif", 
    diseases: 22, 
    tips: 35,
    description: "Important fiber crop for textile industry"
  },
  { 
    name: "Sugarcane", 
    emoji: "🎋", 
    category: "Cash Crop", 
    season: "Annual", 
    diseases: 14, 
    tips: 22,
    description: "Major source of sugar and biofuel"
  },
  { 
    name: "Soybean", 
    emoji: "🫘", 
    category: "Oil Seed", 
    season: "Kharif", 
    diseases: 16, 
    tips: 30,
    description: "Important protein-rich oilseed crop"
  },
  { 
    name: "Mustard", 
    emoji: "🌻", 
    category: "Oil Seed", 
    season: "Rabi", 
    diseases: 10, 
    tips: 18,
    description: "Major oilseed crop grown in winter season"
  },
  { 
    name: "Groundnut", 
    emoji: "🥜", 
    category: "Oil Seed", 
    season: "Both", 
    diseases: 13, 
    tips: 24,
    description: "Important oilseed and protein source"
  },
  { 
    name: "Tomato", 
    emoji: "🍅", 
    category: "Vegetable", 
    season: "Both", 
    diseases: 20, 
    tips: 40,
    description: "Popular vegetable crop with high nutritional value"
  }
];

export const Crops = ({ language }: CropsProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [seasonFilter, setSeasonFilter] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const navigate = useNavigate();

  const filteredCrops = crops.filter(crop => {
    const matchesSearch = crop.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "all" || crop.category === categoryFilter;
    const matchesSeason = seasonFilter === "all" || crop.season === seasonFilter || crop.season === "Both";
    return matchesSearch && matchesCategory && matchesSeason;
  });

  const categories = [...new Set(crops.map(crop => crop.category))];
  const seasons = [...new Set(crops.map(crop => crop.season))];

  const handleCropClick = (cropName: string) => {
    navigate(`/crop/${cropName.toLowerCase()}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Crop Information</h1>
          <p className="text-lg text-muted-foreground max-w-3xl">
            Explore comprehensive information about various crops including growing conditions, 
            common diseases, and expert cultivation tips.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search crops..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Season Filter */}
            <Select value={seasonFilter} onValueChange={setSeasonFilter}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Season" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Seasons</SelectItem>
                {seasons.map(season => (
                  <SelectItem key={season} value={season}>{season}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* View Mode Toggle */}
            <div className="flex border border-border rounded-lg p-1">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className="px-3"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className="px-3"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-4">
          <p className="text-sm text-muted-foreground">
            Showing {filteredCrops.length} of {crops.length} crops
          </p>
        </div>

        {/* Crops Grid/List */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCrops.map((crop) => (
              <Card 
                key={crop.name}
                className="crop-card cursor-pointer group"
                onClick={() => handleCropClick(crop.name)}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="text-3xl">{crop.emoji}</div>
                    <div className="flex-1">
                      <CardTitle className="text-xl">{crop.name}</CardTitle>
                      <div className="flex space-x-2 mt-1">
                        <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                          {crop.category}
                        </span>
                        <span className="text-xs px-2 py-1 bg-secondary/50 text-secondary-foreground rounded-full">
                          {crop.season}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4 text-sm leading-relaxed">
                    {crop.description}
                  </CardDescription>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{crop.diseases} diseases covered</span>
                    <span>{crop.tips} tips available</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredCrops.map((crop) => (
              <Card 
                key={crop.name}
                className="crop-card cursor-pointer group"
                onClick={() => handleCropClick(crop.name)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="text-4xl">{crop.emoji}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <CardTitle className="text-xl">{crop.name}</CardTitle>
                        <div className="flex space-x-2">
                          <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                            {crop.category}
                          </span>
                          <span className="text-xs px-2 py-1 bg-secondary/50 text-secondary-foreground rounded-full">
                            {crop.season}
                          </span>
                        </div>
                      </div>
                      <CardDescription className="mb-3">
                        {crop.description}
                      </CardDescription>
                      <div className="flex space-x-6 text-sm text-muted-foreground">
                        <span>{crop.diseases} diseases covered</span>
                        <span>{crop.tips} tips available</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {filteredCrops.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground mb-4">
              No crops found matching your criteria
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchQuery("");
                setCategoryFilter("all");
                setSeasonFilter("all");
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};