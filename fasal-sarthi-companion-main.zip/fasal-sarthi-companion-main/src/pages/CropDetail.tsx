import { useParams } from "react-router-dom";
import { ArrowLeft, Thermometer, Droplets, Mountain, Calendar, Bug, Lightbulb, BookOpen, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";

interface CropDetailProps {
  language: string;
}

const cropData: Record<string, any> = {
  wheat: {
    name: "Wheat",
    emoji: "🌾",
    description: "Wheat is one of the most important cereal crops worldwide, providing staple food for billions of people.",
    climate: "Cool and dry climate with moderate rainfall",
    soil: "Well-drained loamy soil with pH 6.0-7.5",
    temperature: "15°C - 25°C",
    rainfall: "300-400mm annually",
    season: "Rabi (Winter season)",
    diseases: [
      {
        name: "Leaf Rust",
        symptoms: "Orange to reddish-brown pustules on leaves",
        treatment: "Apply fungicides like Propiconazole",
        prevention: "Use resistant varieties, proper field sanitation"
      },
      {
        name: "Powdery Mildew",
        symptoms: "White powdery growth on leaves and stems",
        treatment: "Spray with Sulfur-based fungicides",
        prevention: "Avoid overcrowding, ensure good air circulation"
      },
      {
        name: "Fusarium Head Blight",
        symptoms: "Bleached spikelets, pink fungal growth",
        treatment: "Apply Tebuconazole during flowering",
        prevention: "Crop rotation, avoid wheat-on-wheat planting"
      }
    ],
    tips: [
      "Plant at the right time - late October to mid-November",
      "Maintain proper seed rate (100-125 kg/hectare)",
      "Apply balanced fertilizers (120:60:40 NPK kg/ha)",
      "Ensure timely irrigation at critical growth stages",
      "Monitor for pests and diseases regularly",
      "Harvest when moisture content is 18-20%"
    ]
  },
  rice: {
    name: "Rice",
    emoji: "🍚",
    description: "Rice is the primary food crop and staple food for more than half of the world's population.",
    climate: "Warm and humid climate with high rainfall",
    soil: "Clay or clay-loam soil that can retain water",
    temperature: "20°C - 35°C",
    rainfall: "1000-2000mm annually",
    season: "Kharif (Monsoon season)",
    diseases: [
      {
        name: "Blast Disease",
        symptoms: "Diamond-shaped lesions with gray centers",
        treatment: "Apply Tricyclazole or Carbendazim",
        prevention: "Use resistant varieties, balanced fertilization"
      },
      {
        name: "Brown Spot",
        symptoms: "Brown oval spots with yellow halos",
        treatment: "Spray with Mancozeb or Copper oxychloride",
        prevention: "Proper water management, avoid potassium deficiency"
      }
    ],
    tips: [
      "Transplant 20-25 day old seedlings",
      "Maintain 2-3 cm water level in the field",
      "Apply organic matter before planting",
      "Use recommended spacing (20x15 cm)",
      "Regular weeding in early stages"
    ]
  }
};

export const CropDetail = ({ language }: CropDetailProps) => {
  const { cropName } = useParams();
  const crop = cropData[cropName || ''] || cropData.wheat;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="text-6xl">{crop.emoji}</div>
            <div>
              <h1 className="text-4xl font-bold text-foreground">{crop.name}</h1>
              <p className="text-lg text-muted-foreground mt-2">{crop.description}</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="diseases">Diseases</TabsTrigger>
            <TabsTrigger value="tips">Tips</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="crop-card">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Thermometer className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">Climate</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{crop.climate}</p>
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Temperature:</span>
                      <Badge variant="secondary">{crop.temperature}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Season:</span>
                      <Badge variant="outline">{crop.season}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="crop-card">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Mountain className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">Soil Requirements</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{crop.soil}</p>
                </CardContent>
              </Card>

              <Card className="crop-card">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Droplets className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">Water Requirements</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Annual Rainfall: {crop.rainfall}</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Diseases Tab */}
          <TabsContent value="diseases" className="space-y-6">
            <div className="grid gap-6">
              {crop.diseases.map((disease: any, index: number) => (
                <Card key={index} className="crop-card">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Bug className="h-5 w-5 text-destructive" />
                      <CardTitle className="text-xl text-destructive">{disease.name}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Symptoms:</h4>
                      <p className="text-muted-foreground">{disease.symptoms}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Treatment:</h4>
                      <p className="text-muted-foreground">{disease.treatment}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Prevention:</h4>
                      <p className="text-muted-foreground">{disease.prevention}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tips Tab */}
          <TabsContent value="tips" className="space-y-6">
            <Card className="crop-card">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <CardTitle className="text-xl">Best Practices for {crop.name} Cultivation</CardTitle>
                </div>
                <CardDescription>
                  Expert recommendations to maximize your crop yield
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {crop.tips.map((tip: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 shrink-0" />
                      <span className="text-muted-foreground">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="crop-card">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    <CardTitle>Related Books & Guides</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <h4 className="font-medium">Complete Guide to {crop.name} Farming</h4>
                    <p className="text-sm text-muted-foreground">Comprehensive cultivation manual</p>
                  </div>
                  <div className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <h4 className="font-medium">{crop.name} Disease Management</h4>
                    <p className="text-sm text-muted-foreground">Prevention and treatment strategies</p>
                  </div>
                  <div className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <h4 className="font-medium">Modern {crop.name} Techniques</h4>
                    <p className="text-sm text-muted-foreground">Latest farming innovations</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="crop-card">
                <CardHeader>
                  <CardTitle>Get Expert Help</CardTitle>
                  <CardDescription>
                    Need personalized advice for your {crop.name} crop?
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full" onClick={() => window.location.href = '/chat'}>
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Ask Our AI Assistant
                  </Button>
                  <Button variant="outline" className="w-full">
                    <BookOpen className="mr-2 h-4 w-4" />
                    Browse More Resources
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};